/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback, useRef, type ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Timer, Zap, Target, RotateCcw, Keyboard } from 'lucide-react';
import { PARAGRAPHS } from './paragraphs';

export default function App() {
  const [sessionIndex, setSessionIndex] = useState(0);
  const [targetText, setTargetText] = useState(PARAGRAPHS[0]);
  const [userInput, setUserInput] = useState(PARAGRAPHS[0][0]);
  const [extraInput, setExtraInput] = useState("");
  const [startTime, setStartTime] = useState<number | null>(null);
  const [endTime, setEndTime] = useState<number | null>(null);
  const [isError, setIsError] = useState(false);
  const [totalAttempts, setTotalAttempts] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  const LogoIcon = ({ className = "w-10 h-10" }: { className?: string }) => (
    <div className={`relative ${className}`}>
      <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
        <rect width="100" height="100" rx="20" fill="url(#logo-grad)" fillOpacity="0.1" />
        <path d="M35 30H65V40H55V75H45V40H35V30Z" fill="url(#logo-grad)" />
        {/* Simple Pro text representation in path if needed, or keeping it abstract */}
        <path d="M60 55L75 65L65 67L68 75L64 77L61 69L55 72L60 55Z" fill="#22d3ee" />
        <defs>
          <linearGradient id="logo-grad" x1="35" y1="30" x2="75" y2="75" gradientUnits="userSpaceOnUse">
            <stop stopColor="#3b82f6" />
            <stop offset="1" stopColor="#22d3ee" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );

  const resetGame = useCallback((nextIndex?: number) => {
    const idx = typeof nextIndex === 'number' ? nextIndex % PARAGRAPHS.length : sessionIndex;
    const pText = PARAGRAPHS[idx];
    
    setSessionIndex(idx);
    setTargetText(pText);
    setUserInput(pText[0]);
    setExtraInput("");
    setStartTime(null);
    setEndTime(null);
    setIsError(false);
    setTotalAttempts(0);
    setIsFinished(false);
    if (!hasStarted) setHasStarted(true);
  }, [sessionIndex, hasStarted]);

  const selectParagraph = (index: number) => {
    resetGame(index);
  };

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Handle global reset on Escape
    if (e.key === 'Escape') {
      resetGame();
      return;
    }

    if (!hasStarted) return;

    if (isFinished) {
      // Allow restart on Enter or Space once finished
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        resetGame();
      }
      return;
    }

    // Prevent default actions for specific keys to stop scrolling or triggering focused buttons
    if (e.key === ' ' || e.key === 'Tab') {
      e.preventDefault();
    }

    // Ignore special keys (except Backspace for correction)
    if (e.key.length !== 1 && e.key !== 'Backspace') return;

    if (!startTime && e.key !== 'Backspace') {
      setStartTime(Date.now());
    }

    if (e.key === 'Backspace') {
      if (extraInput.length > 0) {
        setExtraInput(prev => prev.slice(0, -1));
      } else if (userInput.length > 0 && !isFinished) {
        setUserInput(prev => prev.slice(0, -1));
      }
      return;
    }

    setTotalAttempts(prev => prev + 1);

    const currentIndex = userInput.length;
    const isAtEnd = currentIndex === targetText.length;

    if (!isAtEnd) {
      if (e.key === targetText[currentIndex]) {
        const nextInput = userInput + e.key;
        setUserInput(nextInput);
        setIsError(false);
        
        if (nextInput.length === targetText.length) {
          setEndTime(Date.now());
          setIsFinished(true);
        }
      } else {
        setIsError(true);
        setTimeout(() => setIsError(false), 400);
      }
    } else {
      // Extra characters beyond paragraph length
      setExtraInput(prev => prev + e.key);
    }
  }, [userInput, extraInput, targetText, startTime, isFinished, hasStarted, sessionIndex, resetGame]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const calculateStats = () => {
    if (!startTime || !endTime) return { wpm: 0, accuracy: 0 };
    const seconds = (endTime - startTime) / 1000;
    const minutes = seconds / 60;
    const words = targetText.length / 5; // Standard word length
    const wpm = Math.round(words / minutes);
    const accuracy = Math.round(((targetText.length - 1) / totalAttempts) * 100) || 0;
    return { wpm, accuracy };
  };

  const { wpm, accuracy } = calculateStats();

  if (!hasStarted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-12 bg-[#05070a] text-slate-300 font-sans selection:bg-blue-500/30 relative overflow-hidden">
        <div className="absolute top-12 left-12 flex items-center space-x-4 opacity-50 z-20">
          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
          <span className="text-xs font-bold tracking-[0.2em] uppercase">TypeFlow v2.0</span>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full glass p-10 sm:p-12 rounded-3xl text-center flex flex-col items-center z-10"
        >
          <div className="mb-8 p-1">
            <LogoIcon className="w-20 h-20 shadow-2xl" />
          </div>
          <h1 className="text-4xl font-light mono mb-4 leading-none">Type Pro</h1>
          <p className="text-slate-500 text-sm mb-12 max-w-xs uppercase tracking-widest leading-loose">
            Master your speed across 250+ unique stages
          </p>
          
          <div className="w-full space-y-4">
            <button 
              onClick={() => resetGame(0)}
              className="w-full py-5 bg-blue-600 text-white rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-blue-500 transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] active:scale-95"
            >
              Start Practice
            </button>

            {deferredPrompt && (
              <button 
                onClick={handleInstallClick}
                className="w-full py-4 bg-white/5 border border-white/10 text-slate-300 rounded-xl font-bold uppercase tracking-widest text-[10px] hover:bg-white/10 transition-all flex items-center justify-center space-x-2"
              >
                <Zap className="w-3 h-3" />
                <span>Install Mobile App</span>
              </button>
            )}
          </div>
        </motion.div>

        {/* Backdrop Decor */}
        <div className="fixed inset-0 pointer-events-none opacity-5">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full blur-[120px]" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-12 bg-[#05070a] text-slate-300 font-sans selection:bg-blue-500/30 relative">
      {/* Immersive Header Decor */}
      <div className="absolute top-12 left-12 flex items-center space-x-3 opacity-80 z-20">
        <LogoIcon className="w-6 h-6" />
        <span className="text-xs font-bold tracking-[0.2em] uppercase text-blue-400">Type Pro v2.0</span>
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-4xl z-10 flex flex-col items-center"
      >
        {/* Statistics Top Bar */}
        <div className="flex space-x-12 mb-16">
          <StatItem 
            label="Speed" 
            value={`${isFinished ? wpm : (startTime ? Math.round((userInput.length / 5) / ((Date.now() - startTime) / 60000)) || 0 : 0)}`} 
            unit="WPM" 
          />
          <StatItem 
            label="Accuracy" 
            value={`${isFinished ? accuracy : (totalAttempts > 0 ? Math.round(((userInput.length - 1) / totalAttempts) * 100) : 100)}`} 
            unit="%" 
          />
          <StatItem 
            label="Timer" 
            value={startTime && !endTime ? `${Math.floor((Date.now() - startTime) / 1000)}` : isFinished ? `${Math.floor((endTime! - startTime!) / 1000)}` : "0"} 
            unit="S" 
          />
        </div>

        {/* Level Indicator */}
        <div className="mb-8 flex flex-col items-center gap-1">
          <div className="text-[10px] uppercase tracking-[0.4em] font-bold text-blue-500/60">Stage {sessionIndex + 1}</div>
          <div className="h-1 w-32 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${((sessionIndex + 1) / PARAGRAPHS.length) * 100}%` }}
              className="h-full bg-blue-500"
            />
          </div>
        </div>

        {/* Main Typing Area */}
        <div 
          className={`relative w-full transition-transform duration-200 ${isError ? 'shake' : ''}`}
        >
          <div className="mono text-3xl leading-relaxed text-slate-600 select-none">
            {targetText.split('').map((char, index) => {
              const isCorrect = index < userInput.length;
              const isCurrent = index === userInput.length && !isFinished;
              
              let className = "";
              if (isCorrect) {
                className = "char-correct";
              } else if (isCurrent) {
                className = "cursor char-current";
              }
              
              return (
                <span 
                  key={index} 
                  className={className}
                >
                  {char}
                </span>
              );
            })}
            <AnimatePresence>
              {extraInput && (
                <motion.span 
                  initial={{ opacity: 0, x: -5 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="char-extra"
                >
                  {extraInput}
                </motion.span>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Instructions Footer */}
        <div className="mt-20 flex flex-col items-center gap-6">
          <p className="text-xs uppercase tracking-[0.3em] opacity-20">Type the text above to begin the session</p>
          <div className="flex space-x-4 justify-center">
            <button 
              onClick={() => resetGame()}
              className="glass px-6 py-2 rounded text-[10px] uppercase font-bold tracking-widest text-slate-400 hover:text-white hover:bg-white/5 transition-all"
            >
              Reset Session (Esc)
            </button>
          </div>
        </div>

        <AnimatePresence>
          {isFinished && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#05070a]/90 backdrop-blur-xl p-4 overflow-y-auto"
            >
              <div className="max-w-md w-full glass p-8 sm:p-10 rounded-3xl text-center flex flex-col items-center my-auto">
                <div className="inline-flex p-3 rounded-2xl bg-blue-500/10 border border-blue-500/20 mb-6 text-blue-400">
                  <Zap className="w-6 h-6" />
                </div>
                <h2 className="text-3xl font-light mono mb-1">Session Complete</h2>
                <p className="text-slate-500 uppercase tracking-widest text-[10px] font-bold mb-8">Performance Report</p>
                
                <div className="grid grid-cols-2 gap-8 w-full mb-10 border-y border-white/5 py-8 text-center">
                  <div className="flex flex-col items-center">
                    <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-1">Speed</div>
                    <div className="text-4xl font-light mono">{wpm}<span className="text-xs opacity-30 ml-1">WPM</span></div>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-1">Accuracy</div>
                    <div className="text-4xl font-light mono">{accuracy}<span className="text-xs opacity-30 ml-2">%</span></div>
                  </div>
                </div>

                <div className="w-full flex items-center justify-center">
                  <button 
                    onClick={() => resetGame(sessionIndex + 1)}
                    className="w-full max-w-xs py-4 bg-blue-600 text-white rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-blue-500 transition-all shadow-[0_0_20px_rgba(37,99,235,0.3)] active:scale-95"
                  >
                    Next Level
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function StatItem({ label, value, unit }: { label: string, value: string, unit: string }) {
  return (
    <div className="text-center">
      <div className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-600 mb-2">{label}</div>
      <div className="text-4xl font-light mono text-slate-300">
        {value}<span className="text-xs opacity-20 ml-1 font-sans">{unit}</span>
      </div>
    </div>
  );
}
